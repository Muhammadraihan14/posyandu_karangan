
<?php $__env->startSection('head'); ?>
    <title>Petugas Detail | Posyandu lansia</title>
    <link href="assets/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<div class="post d-flex flex-column-fluid" id="kt_post">
    <!--begin::Container-->
    <div class="container">

        <div class="col-12">
            <!--begin::Post content-->
            <div class="mb-17">
                <!--begin::Wrapper-->
                <div class="mb-8">
                    <!--begin::Info-->
                    <div class="d-flex flex-wrap mb-6">
                        <!--begin::Item-->
                        <div class="me-9 my-1">
                            <span class="fw-bolder text-gray-400">
                                <?php echo e($data->user->name); ?> 
                                pada <?php echo e($data->created_at->translatedFormat('d M Y, h:i ')); ?>

                            </span>
                            <!--end::Label-->
                        </div>
                    </div>
                    <!--end::Info-->
                    <!--begin::Title-->
                    <a href="#" class="text-dark text-hover-primary fs-2 fw-bolder"><?php echo e($data->judul); ?></a>
                    <!--end::Title-->
                    <!--begin::Container-->
                    <div class="overlay mt-8">
                        <!--begin::Image-->
                        <div class="bgi-no-repeat bgi-position-center bgi-size-cover card-rounded min-h-350px" style="background-image:url('<?php echo e(asset('/upload/'.$data->image_url)); ?>')"></div>
                
                    </div>
                    <!--end::Container-->
                </div>
                <!--end::Wrapper-->
                <!--begin::Description-->
                <div class="fs-5 fw-bold text-black-600">
                    <?php echo $data->isi; ?>

                </div>
                <!--end::Description-->
                <!--begin::Block-->
                
                <!--end::Block-->
                <!--begin::Icons-->
              
                <!--end::Icons-->
            </div>
            <!--end::Post content-->
        </div>
    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('landing.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posyandu_karangan\resources\views/landing/blog/detail.blade.php ENDPATH**/ ?>