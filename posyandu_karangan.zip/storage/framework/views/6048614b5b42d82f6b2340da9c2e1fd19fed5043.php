
<?php $__env->startSection('head'); ?>
    <title>Petugas Detail | Posyandu lansia</title>
    <link href="assets/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<div class="post d-flex flex-column-fluid" id="kt_post">
    <!--begin::Container-->
    <div class="container">
        <div class="row w-100 gy-10 mb-md-20" id="blogss">
            <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <!--begin::Feature post-->
                <div class="card-xl-stretch me-md-6">
                    <!--begin::Image-->
                    <a class="d-block bgi-no-repeat bgi-size-cover bgi-position-center card-rounded position-relative min-h-175px mb-5" style="background-image:url('assets/media/stock/600x400/img-73.jpg')"  href="<?php echo e(route('blog-list.detail', ['id' => $dt->id])); ?>">
                        <img src="<?php echo e(asset('/upload/'.$dt->image_url)); ?>" class="position-absolute top-50 start-50 translate-middle " alt="" />
                    </a>
                    <!--end::Image-->
                    <!--begin::Body-->
                    <div class="m-0">
                        <!--begin::Title-->
                        <a href="#" class="fs-4 text-dark fw-bolder text-hover-primary text-dark lh-base"><?php echo e($dt->judul); ?></a>
                        <!--end::Title-->
                        <!--begin::Text-->
                        
                        <!--end::Text-->
                        <!--begin::Content-->
                        <div class="fs-6 fw-bolder">
                            <!--begin::Author-->
                            <a href="#" class="text-gray-700 text-hover-primary">Jane Miller</a>
                            <!--end::Author-->
                            <!--begin::Date-->
                            <span class="text-muted"><?php echo e($dt->user->name); ?> 
                                <br>
                                pada <?php echo e($dt->created_at->translatedFormat('d M Y, h:i ')); ?></span>
                            <!--end::Date-->
                        </div>
                        <!--end::Content-->
                    </div>
                    <!--end::Body-->
                </div>
                <!--end::Feature post-->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>	
        <?php echo e($blog->links()); ?>


    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('landing.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posyandu_karangan\resources\views/landing/blog/listblog.blade.php ENDPATH**/ ?>