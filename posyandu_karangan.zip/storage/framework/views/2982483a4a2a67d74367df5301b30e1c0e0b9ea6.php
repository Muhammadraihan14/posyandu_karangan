      <!--begin::Modal - New Target-->
      <div class="modal fade" id="tindakan" tabindex="-1" aria-hidden="true">
          <!--begin::Modal dialog-->
          <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content rounded">
                  <!--begin::Modal header-->
                  <div class="modal-header pb-0 border-0 justify-content-end">
                      <!--begin::Close-->
                      <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                          <span class="svg-icon svg-icon-1">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                  fill="none">
                                  <rect opacity="0.5" x="6" y="17.3137" width="16" height="2"
                                      rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                  <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                      transform="rotate(45 7.41422 6)" fill="black" />
                              </svg>
                          </span>
                          <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                  </div>
                  <!--begin::Modal header-->
                  <!--begin::Modal body-->
                  <div class="modal-body scroll-y px-10 px-lg-15 pt-0 pb-15">
                      <form id="kt_modal_new_target_form" class="form" action="<?php echo e(route('lansia.petugas.save.f')); ?>"
                          method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="mb-13 text-center">
                              <h1 class="mb-3">Pemeriksaan Fisik dan Tindakan</h1>
                          </div>
                          
                          <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="user_id" id="user_id">
                          <input type="hidden" value="<?php echo e($data->id); ?>" name="lansia_id" id="lansia_id">
                          <input type="hidden" value="<?php echo e($data->desa_id); ?>" name="desa_id" id="desa_id">

                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Tanggal Pemeriksaan</span>
                                  
                              </label>
                              <!--end::Label-->
                              <input type="date" name="tanggal_p" <?php $__errorArgs = ['tanggal_p'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  class="form-control form-control-solid" required />
                              <?php $__errorArgs = ['tanggal_p'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feddback " role="alert">
                                      <?php echo e($message); ?>

                                  </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <!--end::Input group-->
                          <div class="row g-9 mb-8">
                              <!--begin::Col-->
                              <div class="col-md-6 fv-row">
                                  <label class="required fs-6 fw-bold mb-2">Tinggi Badan</label>
                                  <input type="number" name="tinggi_badan" id="tinggi_badan" <?php $__errorArgs = ['tinggi_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      class="form-control form-control-solid" required />
                                  <?php $__errorArgs = ['tinggi_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feddback " role="alert">
                                          <?php echo e($message); ?>

                                      </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              <!--end::Col-->
                              <!--begin::Col-->
                              <div class="col-md-6 fv-row">
                                  <label class="required fs-6 fw-bold mb-2">Berat Badan</label>
                                  <input type="number" name="berat_badan" id="berat_badan" <?php $__errorArgs = ['berat_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      class="form-control form-control-solid" required />
                                  <?php $__errorArgs = ['berat_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feddback " role="alert">
                                          <?php echo e($message); ?>

                                      </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <!--end::Input group-->
                          <div class="row g-9 mb-8">
                              <!--begin::Col-->
                              <div class="col-md-6 fv-row">
                                  <label class="required fs-6 fw-bold mb-2">Sistole</label>
                                  <input type="number" name="sistole" <?php $__errorArgs = ['sistole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      class="form-control form-control-solid" required />
                                  <?php $__errorArgs = ['sistole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feddback " role="alert">
                                          <?php echo e($message); ?>

                                      </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  
                              </div>
                              <!--end::Col-->
                              <!--begin::Col-->
                              <div class="col-md-6 fv-row">
                                  <label class="required fs-6 fw-bold mb-2">Diastole</label>
                                  <input type="number" name="diastole" <?php $__errorArgs = ['diastole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      class="form-control form-control-solid" required />
                                  <?php $__errorArgs = ['diastole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feddback " role="alert">
                                          <?php echo e($message); ?>

                                      </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Tata Laksana</span>
                                  
                              </label>
                              <!--end::Label-->
                              <input type="text" name="tata_laksana" <?php $__errorArgs = ['tata_laksana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  class="form-control form-control-solid" required />
                              <?php $__errorArgs = ['tata_laksana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feddback " role="alert">
                                      <?php echo e($message); ?>

                                  </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <!--end::Input group-->
                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Konseling</span>
                              </label>
                              <select class="form-select form-select-solid" data-control="select2"
                                  data-hide-search="true" data-placeholder="Select a Team Member" name="konseling"
                                  id="konseling">
                                  <option></option>
                                  <option value="Ya">Ya</option>
                                  <option value="Tidak">Tidak</option>
                              </select>
                          </div>
                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Rujuk</span>
                              </label>
                              <select class="form-select form-select-solid" data-control="select2"
                                  data-hide-search="true" data-placeholder="Select a Team Member" name="rujuk"
                                  id="rujuk">
                                  <option></option>
                                  <option value="Ya">Ya</option>
                                  <option value="Tidak">Tidak</option>
                              </select>
                          </div>

                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Lain-lain</span>
                                  
                              </label>
                              <!--end::Label-->
                              <input type="text" name="lain" <?php $__errorArgs = ['lain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  class="form-control form-control-solid" required />
                              <?php $__errorArgs = ['lain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feddback " role="alert">
                                      <?php echo e($message); ?>

                                  </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="text-center">
                              <button type="reset" id="kt_modal_new_target_cancel" class="btn btn-light me-3"
                                  data-bs-dismiss="modal">Cancel</button>
                              <button type="submit" id="kt_modal_new_target_submit" class="btn btn-primary">
                                  <span class="indicator-label">Submit</span>
                                  <span class="indicator-progress">Please wait...
                                      <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                              </button>
                          </div>
                          <!--end::Actions-->
                      </form>
                      <!--end:Form-->
                  </div>
                  <!--end::Modal body-->
              </div>
              <!--end::Modal content-->
          </div>
          <!--end::Modal dialog-->
      </div>
      <!--end::Modal - New Target-->



<?php $__currentLoopData = $data->pemerisaan_fisik_tindakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <!--begin::Modal - New Target-->
      <div class="modal fade" id="tindakanEdit<?php echo e($val->id); ?>" tabindex="-1" aria-hidden="true">
          <!--begin::Modal dialog-->
          <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content rounded">
                  <!--begin::Modal header-->
                  <div class="modal-header pb-0 border-0 justify-content-end">
                      <!--begin::Close-->
                      <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                          <span class="svg-icon svg-icon-1">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                  viewBox="0 0 24 24" fill="none">
                                  <rect opacity="0.5" x="6" y="17.3137" width="16" height="2"
                                      rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                  <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                      transform="rotate(45 7.41422 6)" fill="black" />
                              </svg>
                          </span>
                          <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                  </div>
                  <!--begin::Modal header-->
                  <!--begin::Modal body-->
                  <div class="modal-body scroll-y px-10 px-lg-15 pt-0 pb-15">
                      <form id="kt_modal_new_target_form" class="form" action="<?php echo e(route('lansia.petugas.save.f')); ?>"
                          method="POST">
                          <?php echo csrf_field(); ?>

                          <div class="mb-13 text-center">
                              <h1 class="mb-3">Pemeriksaan Fisik dan Tindakan edit</h1>
                          </div>
                          <input type="hidden" value="<?php echo e($val->id); ?>" name="id" id="id">
                          <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="user_id" id="user_id">
                          <input type="hidden" value="<?php echo e($data->id); ?>" name="lansia_id" id="lansia_id">
                          <input type="hidden" value="<?php echo e($data->desa_id); ?>" name="desa_id" id="desa_id">

                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Tanggal Pemeriksaan</span>
                                  
                              </label>
                              <!--end::Label-->
                              <input type="date" name="tanggal_p" <?php $__errorArgs = ['tanggal_p'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  class="form-control form-control-solid" required />
                                <div class="invalid-feddback " role="alert">
                                    <p>Terakhir pemeriksaan :
                                        <?php echo e($FisikSelected != null ? $FisikSelected->tanggal_p->format('d M Y') : ''); ?> </p>
                                </div>
                              <?php $__errorArgs = ['tanggal_p'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feddback " role="alert">
                                      <?php echo e($message); ?>

                                  </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <!--end::Input group-->
                          <div class="row g-9 mb-8">
                              <!--begin::Col-->
                              <div class="col-md-6 fv-row">
                                  <label class="required fs-6 fw-bold mb-2">Tinggi Badan</label>
                                  <input type="number" name="tinggi_badan" value="<?php echo e($val->tinggi_badan); ?>"
                                      <?php $__errorArgs = ['tinggi_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      class="form-control form-control-solid" required />
                                  <?php $__errorArgs = ['tinggi_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feddback " role="alert">
                                          <?php echo e($message); ?>

                                      </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              <!--end::Col-->
                              <!--begin::Col-->
                              <div class="col-md-6 fv-row">
                                  <label class="required fs-6 fw-bold mb-2">Berat Badan</label>
                                  <input type="number" name="berat_badan" <?php $__errorArgs = ['berat_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e($val->berat_badan); ?>"
                                      class="form-control form-control-solid" required />
                                  <?php $__errorArgs = ['berat_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feddback " role="alert">
                                          <?php echo e($message); ?>

                                      </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <!--end::Input group-->
                          <div class="row g-9 mb-8">
                              <!--begin::Col-->
                              <div class="col-md-6 fv-row">
                                  <label class="required fs-6 fw-bold mb-2">Sistole</label>
                                  <input type="number" name="sistole" <?php $__errorArgs = ['sistole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e($val->sistole); ?>"
                                      class="form-control form-control-solid" required />
                                  <?php $__errorArgs = ['sistole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feddback " role="alert">
                                          <?php echo e($message); ?>

                                      </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              <!--end::Col-->
                              <!--begin::Col-->
                              <div class="col-md-6 fv-row">
                                  <label class="required fs-6 fw-bold mb-2">Diastole</label>
                                  <input type="number" name="diastole" <?php $__errorArgs = ['diastole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e($val->diastole); ?>"
                                      class="form-control form-control-solid" required />
                                  <?php $__errorArgs = ['diastole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feddback " role="alert">
                                          <?php echo e($message); ?>

                                      </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Tata Laksana</span>
                                  
                              </label>
                              <!--end::Label-->
                              <input type="text" name="tata_laksana" <?php $__errorArgs = ['tata_laksana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e($val->tata_laksana); ?>"
                                  class="form-control form-control-solid" required />
                              <?php $__errorArgs = ['tata_laksana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feddback " role="alert">
                                      <?php echo e($message); ?>

                                  </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <!--end::Input group-->
                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Konseling</span>
                              </label>
                              <select class="form-select form-select-solid" data-control="select2"
                                  data-hide-search="true" data-placeholder="Select a Team Member" name="konseling"
                                  id="konseling">
                                  <option value="<?php echo e($val->konseling); ?>"><?php echo e($val->konseling); ?></option>
                                  <option value="Ya">Ya</option>
                                  <option value="Tidak">Tidak</option>
                              </select>
                          </div>
                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Rujuk</span>
                              </label>
                              <select class="form-select form-select-solid" data-control="select2"
                                  data-hide-search="true" data-placeholder="Select a Team Member" name="rujuk"
                                  id="rujuk">
                                  <option <?php echo e($val->rujuk); ?>><?php echo e($val->rujuk); ?></option>
                                  <option value="Ya">Ya</option>
                                  <option value="Tidak">Tidak</option>
                              </select>
                          </div>

                          <div class="d-flex flex-column mb-8 fv-row">
                              <!--begin::Label-->
                              <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                                  <span class="required">Lain-lain</span>
                                  
                              </label>
                              <!--end::Label-->
                              <input type="text" name="lain" <?php $__errorArgs = ['lain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e($val->lain); ?>"
                                  class="form-control form-control-solid" required />
                              <?php $__errorArgs = ['lain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feddback " role="alert">
                                      <?php echo e($message); ?>

                                  </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="text-center">
                              <button type="reset" id="kt_modal_new_target_cancel" class="btn btn-light me-3"
                                  data-bs-dismiss="modal">Cancel</button>
                              <button type="submit" id="kt_modal_new_target_submit" class="btn btn-primary">
                                  <span class="indicator-label">Submit</span>
                                  <span class="indicator-progress">Please wait...
                                      <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                              </button>
                          </div>
                          <!--end::Actions-->
                      </form>
                      <!--end:Form-->
                  </div>
                  <!--end::Modal body-->
              </div>
              <!--end::Modal content-->
          </div>
          <!--end::Modal dialog-->
      </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <!--end::Modal - New Target-->
<?php $__currentLoopData = $data->pemerisaan_fisik_tindakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <!--begin::Modal - New Target-->
      <div class="modal fade" id="detailFisik<?php echo e($val->id); ?>" tabindex="-1" aria-hidden="true">
          <!--begin::Modal dialog-->
          <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content rounded">
                  <!--begin::Modal header-->
                  <div class="modal-header pb-0 border-0 justify-content-end">
                      <!--begin::Close-->
                      <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                          <span class="svg-icon svg-icon-1">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                  viewBox="0 0 24 24" fill="none">
                                  <rect opacity="0.5" x="6" y="17.3137" width="16" height="2"
                                      rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                  <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                      transform="rotate(45 7.41422 6)" fill="black" />
                              </svg>
                          </span>
                          <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                  </div>
                  <!--begin::Modal header-->
                  <!--begin::Modal body-->
                  <div class="modal-body scroll-y px-10 px-lg-15 pt-0 pb-15">
										<div class="row mb-7">
											<!--begin::Label-->
											<label class="col-lg-4 fw-bold text-muted">Berat Badan</label>
											<!--end::Label-->
											<!--begin::Col-->
											<div class="col-lg-8">
													<span
															class="fw-bolder fs-6 text-gray-800"><?php echo e($data->pemerisaan_fisik_tindakan->last() != null ? $data->pemerisaan_fisik_tindakan->last()->berat_badan : '-'); ?>

															Kg </span>
													
													

											</div>
											<!--end::Col-->
									</div>
									<div class="row mb-7">
											<!--begin::Label-->
											<label class="col-lg-4 fw-bold text-muted">Tinggi Badan</label>
											<!--end::Label-->
											<!--begin::Col-->
											<div class="col-lg-8 fv-row">
													<span
															class="fw-bold text-gray-800 fs-6"><?php echo e($data->pemerisaan_fisik_tindakan->last() != null ? $data->pemerisaan_fisik_tindakan->last()->tinggi_badan : '-'); ?>

															m </span>
													
											</div>
											<!--end::Col-->
									</div>
									<div class="row mb-7">
											<!--begin::Label-->
											<label class="col-lg-4 fw-bold text-muted">IMT</label>
											<!--end::Label-->
											<!--begin::Col-->
											<div class="col-lg-8 fv-row">

													<div class="col-lg-8 d-flex align-items-center">
															<span
																	class="fw-bolder fs-6 text-gray-800 me-2"><?php echo e($val != null ? $val->imt : '-'); ?>

																	Kg/m^2 </span>
															<span
																	class="badge <?php echo e($val->status_gizi == 'Tinggi' ? 'badge-danger' : 'badge-success '); ?>"><?php echo e($val->status_gizi != null ? $val->status_gizi : ''); ?></span>

													</div>
											</div>
											<!--end::Col-->
									</div>
									<div class="row mb-7">
											<label class="col-lg-4 fw-bold text-muted">Tekanan Darah </label>
											<div class="col-lg-8 fv-row">
													<span
															class="fw-bold text-gray-800 fs-6"><?php echo e($val != null ? $val->sistole : '-'); ?>

															/
															<?php echo e($val != null ? $val->diastole : '-'); ?>

															mmHg </span>
													<span
															class="badge <?php echo e($val->tekanan_darah == 'Tinggi' ? 'badge-danger' : 'badge-success '); ?>"><?php echo e($val->tekanan_darah != null ? $val->tekanan_darah : ''); ?></span>
											</div>
									</div>
									<div class="row mb-7">
											<label class="col-lg-4 fw-bold text-muted">Konseling </label>
											<div class="col-lg-8 fv-row">
												<span class="fw-bold text-gray-800 fs-6"><?php echo e($val->konseling != null ? $val->konseling : '-'); ?></span>
										</div>
									</div>
									<div class="row mb-7">
											<label class="col-lg-4 fw-bold text-muted">Rujuk </label>
											<div class="col-lg-8 fv-row">
												<span class="fw-bold text-gray-800 fs-6"><?php echo e($val->rujuk != null ? $val->rujuk : '-'); ?></span>
										</div>
									</div>
									<div class="row mb-7">
											<label class="col-lg-4 fw-bold text-muted">Tata Laksana </label>
											<div class="col-lg-8 fv-row">
												<span class="fw-bold text-gray-800 fs-6"><?php echo e($val->tata_laksana != null ? $val->tata_laksana : '-'); ?></span>
										</div>
									</div>
									<div class="row mb-7">
											<label class="col-lg-4 fw-bold text-muted">Lain-lain </label>
											<div class="col-lg-8 fv-row">
												<span class="fw-bold text-gray-800 fs-6"><?php echo e($val->lain != null ? $val->lain : '-'); ?></span>
										</div>
									</div>
									<div class="row mb-7">
											<label class="col-lg-4 fw-bold text-muted">Terakhir Pemeriksaaan</label>
											<div class="col-lg-8 fv-row">
													<span class="fw-bold text-gray-800 fs-6"><?php echo e($val->tanggal_p != null ? $val->tanggal_p->translatedFormat('d M Y, h:i A') : '-'); ?></span>
											</div>
									</div>
									<div class="row mb-7">
											<label class="col-lg-4 fw-bold text-muted">Diperiksa Oleh</label>
											<div class="col-lg-8 fv-row">
													<span
															class="fw-bold text-gray-800 fs-6"><?php echo e($val->user->name != null ? $val->user->name : '-'); ?></span>
											</div>
									</div>
                      <!--end:Form-->
                  </div>
                  <!--end::Modal body-->
              </div>
              <!--end::Modal content-->
          </div>
          <!--end::Modal dialog-->
      </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <!--end::Modal - New Target-->

<?php /**PATH C:\xampp\htdocs\posyandu_karangan\resources\views/petugas/lansia/form/modal_fisik_tindakan.blade.php ENDPATH**/ ?>